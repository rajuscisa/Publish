//var BaseURL = 'https://pricing.servion.com/RouteApps/';
var BaseURL = 'http://localhost:3000/';
var View360ImagesPath = 'img/';
var ServionImages = 'images/';
//var HostPath = "/PricingTool";
var HostPath = "/PT";
var urltype = location.protocol;
